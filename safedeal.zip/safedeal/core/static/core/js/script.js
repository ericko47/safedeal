<script>
  // Simulate user role for the demo
  const userType = "seller"; // Replace with dynamic value based on logged-in user

  if (userType === "seller") {
    document.getElementById('post-section').style.display = "block";
  }
</script>

<script>
  // Simulate user role for the demo
  const userType = "seller"; // Replace with dynamic value based on logged-in user

  if (userType === "seller") {
    document.getElementById('post-section').style.display = "block";
  }
</script>
